# Al-Miftah — Portal Akademik PAI Kelas VIII (Full-Stack)

Backend (Node.js/Express) + frontend (HTML/CSS/JS) untuk portal materi, tugas,
evaluasi, nilai, dan riwayat belajar siswa kelas VIII mapel PAI.

## Struktur folder

```
portal-pai/
├── server.js              # backend Express (semua API)
├── package.json
├── lib/
│   └── store.js           # akses data (file JSON sebagai "database")
├── data/
│   ├── siswa.json         # daftar siswa (bisa diganti via impor spreadsheet)
│   ├── materi.json        # 6 bab materi PAI kelas VIII
│   ├── tugas.json         # daftar tugas
│   ├── evaluasi.json      # bank soal + kunci jawaban (hanya dibaca server)
│   ├── info.json          # pengumuman
│   └── progress.json      # nilai & status belajar tiap siswa (terisi otomatis)
├── public/
│   ├── index.html
│   ├── style.css
│   └── app.js              # frontend, memanggil API lewat fetch()
└── contoh-daftar-siswa.csv # contoh format spreadsheet untuk impor
```

## Cara menjalankan

Prasyarat: [Node.js](https://nodejs.org) versi 18 ke atas sudah terpasang.

```bash
cd portal-pai
npm install
npm start
```

Lalu buka **http://localhost:3000** di browser.

Selama proses berjalan, semua siswa di jaringan yang sama bisa mengakses
`http://<alamat-IP-komputer-ini>:3000` dari HP/laptop masing-masing. Untuk
diakses dari luar sekolah/internet, deploy `server.js` ke layanan hosting
Node.js (misalnya Railway, Render, atau VPS) — folder `public/` ikut
tersaji otomatis oleh server yang sama.

## Cara login

Siswa memilih namanya sendiri dari daftar kelas (tombol **Masuk** di pojok
kanan atas) — tanpa kata sandi. Setelah itu status materi, tugas, dan nilai
evaluasi tersimpan di **server** (bukan hanya di satu perangkat), sehingga
tetap sama walau dibuka dari perangkat lain, selama backend yang sama yang
diakses.

## Mengganti daftar siswa dari spreadsheet

Siapkan file **.xlsx** atau **.csv** dengan kolom `Nama`, `Kelas`, dan
`NIS` (opsional) — contohnya lihat `contoh-daftar-siswa.csv`. Lalu kirim
lewat endpoint impor, misalnya dengan `curl`:

```bash
curl -X POST http://localhost:3000/api/admin/import-siswa \
  -F "file=@contoh-daftar-siswa.csv"
```

Atau pakai aplikasi seperti Postman/Insomnia: method `POST`, url
`/api/admin/import-siswa`, body `form-data` dengan key `file` bertipe File.

Setelah berhasil, `data/siswa.json` otomatis diperbarui dan daftar login di
frontend langsung mengikuti data baru (refresh halaman).

> Catatan: endpoint ini belum diberi proteksi login admin — cocok untuk
> pemakaian internal sekolah. Untuk pemakaian publik/produksi, tambahkan
> autentikasi guru (misalnya token sederhana) sebelum endpoint ini dibuka
> ke internet.

## Mengubah materi, tugas, atau soal evaluasi

Edit langsung file JSON di folder `data/` (`materi.json`, `tugas.json`,
`evaluasi.json`, `info.json`) lalu restart server (`npm start` ulang).
Formatnya array JSON biasa, mudah disunting.

## Cara kerja skor evaluasi

Kunci jawaban disimpan hanya di `data/evaluasi.json` dan **tidak pernah
dikirim ke browser** sebelum siswa submit — endpoint `GET /api/evaluasi`
hanya mengirim pertanyaan dan pilihan jawaban. Penilaian dihitung di
`POST /api/evaluasi/:id/submit`, lalu hasilnya (termasuk kunci jawaban
untuk pembahasan) baru dikirim balik setelah siswa selesai mengerjakan.

## Ringkasan API

| Method | Endpoint                         | Keterangan                                  |
|--------|-----------------------------------|----------------------------------------------|
| GET    | `/api/siswa`                     | Daftar siswa untuk jendela login             |
| POST   | `/api/login`                     | `{studentId}` → data siswa                   |
| POST   | `/api/admin/import-siswa`        | Unggah spreadsheet, ganti daftar siswa       |
| GET    | `/api/materi`                    | Daftar materi                                |
| GET    | `/api/tugas`                     | Daftar tugas                                 |
| GET    | `/api/info`                      | Daftar pengumuman                            |
| GET    | `/api/evaluasi`                  | Daftar evaluasi (tanpa kunci jawaban)        |
| POST   | `/api/evaluasi/:id/submit`       | `{studentId, answers}` → skor & pembahasan   |
| POST   | `/api/progress/materi`           | `{studentId, materiId, done}`                |
| POST   | `/api/progress/tugas`            | `{studentId, tugasId, done}`                 |
| GET    | `/api/riwayat/:studentId`        | Data siswa + seluruh progres (nilai, status) |
