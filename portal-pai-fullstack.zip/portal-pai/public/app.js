(function () {
  "use strict";

  const API = ""; // sama origin (backend & frontend disajikan dari server yang sama)

  // ---------- state ----------
  let MATERI = [], TUGAS = [], EVALUASI = [], INFO = [], ROSTER = [];
  let currentStudent = null; // {id, nama, kelas}
  let progress = { materiDone: {}, tugasDone: {}, nilai: {} };

  const LS_KEY = "pai_current_student_id";

  function initials(name) {
    return name.trim().split(/\s+/).slice(0, 2).map((w) => w[0]).join("").toUpperCase();
  }

  async function api(path, options) {
    const res = await fetch(API + path, {
      headers: { "Content-Type": "application/json" },
      ...options,
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || "Terjadi kesalahan pada server.");
    return data;
  }

  // ---------- auth ----------
  async function restoreSession() {
    let sid = null;
    try { sid = localStorage.getItem(LS_KEY); } catch (e) {}
    if (!sid) return;
    try {
      const data = await api("/api/riwayat/" + sid);
      currentStudent = data.siswa;
      progress = data.progress;
    } catch (e) {
      try { localStorage.removeItem(LS_KEY); } catch (err) {}
    }
  }

  async function loginAs(studentId) {
    const siswa = await api("/api/login", { method: "POST", body: JSON.stringify({ studentId }) });
    currentStudent = siswa;
    try { localStorage.setItem(LS_KEY, siswa.id); } catch (e) {}
    const data = await api("/api/riwayat/" + siswa.id);
    progress = data.progress;
    renderAll();
  }

  function logout() {
    currentStudent = null;
    progress = { materiDone: {}, tugasDone: {}, nilai: {} };
    try { localStorage.removeItem(LS_KEY); } catch (e) {}
    switchView("beranda");
    renderAll();
  }

  // ---------- login modal ----------
  const loginModal = document.getElementById("loginModal");
  const studentList = document.getElementById("studentList");
  const studentSearch = document.getElementById("studentSearch");

  function openLogin() {
    studentSearch.value = "";
    renderStudentList("");
    loginModal.classList.add("open");
    setTimeout(() => studentSearch.focus(), 50);
  }
  function closeLogin() { loginModal.classList.remove("open"); }
  document.getElementById("closeModal").addEventListener("click", closeLogin);
  loginModal.addEventListener("click", (e) => { if (e.target === loginModal) closeLogin(); });
  studentSearch.addEventListener("input", () => renderStudentList(studentSearch.value));

  function renderStudentList(query) {
    const q = query.trim().toLowerCase();
    const filtered = ROSTER.filter((s) => s.nama.toLowerCase().includes(q));
    if (filtered.length === 0) {
      studentList.innerHTML = `<div class="no-result">Nama tidak ditemukan. Hubungi guru jika namamu belum terdaftar.</div>`;
      return;
    }
    const groups = {};
    filtered.forEach((s) => { (groups[s.kelas] = groups[s.kelas] || []).push(s); });
    let html = "";
    Object.keys(groups).sort().forEach((kelas) => {
      html += `<div class="kelas-group-label">Kelas ${kelas}</div>`;
      groups[kelas].forEach((s) => {
        html += `<button class="student-row" data-id="${s.id}"><span class="av">${initials(s.nama)}</span><span>${s.nama}</span></button>`;
      });
    });
    studentList.innerHTML = html;
    studentList.querySelectorAll(".student-row").forEach((btn) => {
      btn.addEventListener("click", async () => {
        closeLogin();
        try { await loginAs(btn.dataset.id); } catch (e) { alert(e.message); }
      });
    });
  }

  // ---------- nav ----------
  const views = document.querySelectorAll(".view");
  const navBtns = document.querySelectorAll(".nav-btn");
  function switchView(target) {
    navBtns.forEach((b) => b.classList.toggle("active", b.dataset.view === target));
    views.forEach((v) => v.classList.toggle("active", v.id === "view-" + target));
    window.scrollTo({ top: 0, behavior: "smooth" });
  }
  navBtns.forEach((btn) => {
    btn.addEventListener("click", () => {
      const target = btn.dataset.view;
      if (target === "riwayat" && !currentStudent) { openLogin(); return; }
      switchView(target);
      if (target === "riwayat") renderRiwayat();
    });
  });

  // ---------- topbar ----------
  function renderAuthArea() {
    const el = document.getElementById("authArea");
    if (currentStudent) {
      el.innerHTML = `
        <div class="auth-chip">
          <div class="av">${initials(currentStudent.nama)}</div>
          <div class="who"><b>${currentStudent.nama}</b>Kelas ${currentStudent.kelas}</div>
          <button id="logoutBtn">Keluar</button>
        </div>`;
      document.getElementById("logoutBtn").addEventListener("click", logout);
    } else {
      el.innerHTML = `<button class="login-btn" id="loginTopBtn">Masuk</button>`;
      document.getElementById("loginTopBtn").addEventListener("click", openLogin);
    }
    document.getElementById("riwayatLockDot").style.display = currentStudent ? "none" : "inline-block";
  }

  function renderGreeting() {
    const hour = new Date().getHours();
    document.getElementById("greetTime").textContent =
      hour < 11 ? "Selamat pagi, semangat belajar" : hour < 15 ? "Selamat siang, tetap fokus" : hour < 18 ? "Selamat sore, sedikit lagi" : "Selamat malam, jangan lupa istirahat";
    document.getElementById("greetName").textContent = "Assalamu'alaikum" + (currentStudent ? ", " + currentStudent.nama.split(" ")[0] : "");
    document.getElementById("todayDate").textContent = new Date().toLocaleDateString("id-ID", { weekday: "long", day: "numeric", month: "long", year: "numeric" });
  }

  // ---------- materi ----------
  function renderMateri() {
    const el = document.getElementById("materiList");
    el.innerHTML = "";
    MATERI.forEach((m, idx) => {
      const done = !!progress.materiDone[m.id];
      const card = document.createElement("div");
      card.className = "materi-card";
      card.innerHTML = `
        <div class="materi-head">
          <div class="materi-num">${String(idx + 1).padStart(2, "0")}</div>
          <div class="materi-titles"><div class="bab">${m.bab}</div><h3>${m.judul}</h3></div>
          <span class="pill ${!currentStudent ? "neutral" : done ? "good" : "gold"}">${!currentStudent ? "Login untuk menandai" : done ? "Selesai dipelajari" : "Belum dipelajari"}</span>
          <svg class="chev" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 9l6 6 6-6"/></svg>
        </div>
        <div class="materi-body">
          <div class="materi-body-inner">
            <p>${m.ringkasan}</p>
            <ul>${m.poin.map((p) => `<li>${p}</li>`).join("")}</ul>
            <div class="ayat-box"><div class="ar">${m.ayatAr}</div><div>${m.ayatId}</div></div>
            <button class="mark-btn ${done ? "done" : ""}" data-id="${m.id}">${!currentStudent ? "Login untuk menandai" : done ? "✓ Sudah dipelajari" : "Tandai sudah dipelajari"}</button>
          </div>
        </div>`;
      el.appendChild(card);
    });
    el.querySelectorAll(".materi-head").forEach((h) => h.addEventListener("click", () => h.closest(".materi-card").classList.toggle("open")));
    el.querySelectorAll(".mark-btn").forEach((b) => {
      b.addEventListener("click", async (e) => {
        e.stopPropagation();
        if (!currentStudent) { openLogin(); return; }
        const id = b.dataset.id;
        const done = !progress.materiDone[id];
        try {
          progress = await api("/api/progress/materi", { method: "POST", body: JSON.stringify({ studentId: currentStudent.id, materiId: id, done }) });
          renderMateri();
        } catch (err) { alert(err.message); }
      });
    });
  }

  // ---------- tugas ----------
  function renderTugas() {
    const el = document.getElementById("tugasList");
    el.innerHTML = "";
    TUGAS.forEach((t) => {
      const materi = MATERI.find((m) => m.id === t.materiId);
      const done = !!progress.tugasDone[t.id];
      const item = document.createElement("div");
      item.className = "tugas-item" + (done ? " done" : "");
      item.innerHTML = `
        <button class="check-toggle ${done ? "on" : ""}" data-id="${t.id}" aria-label="Tandai selesai">
          ${done ? '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="3"><path d="M5 13l4 4L19 7"/></svg>' : ""}
        </button>
        <div class="tugas-text">
          <h4>${t.judul}</h4>
          <div class="meta">${materi ? materi.bab + " · " + materi.judul : ""} · Tenggat: ${t.tenggat}</div>
          <p>${t.deskripsi}</p>
        </div>`;
      el.appendChild(item);
    });
    el.querySelectorAll(".check-toggle").forEach((b) => {
      b.addEventListener("click", async () => {
        if (!currentStudent) { openLogin(); return; }
        const id = b.dataset.id;
        const done = !progress.tugasDone[id];
        try {
          progress = await api("/api/progress/tugas", { method: "POST", body: JSON.stringify({ studentId: currentStudent.id, tugasId: id, done }) });
          renderTugas();
        } catch (err) { alert(err.message); }
      });
    });
  }

  // ---------- evaluasi ----------
  const quizPicker = document.getElementById("quizPicker");
  const quizRunnerWrap = document.getElementById("quizRunnerWrap");

  function predikat(skor) {
    if (skor >= 90) return { label: "Sangat Baik (A)", cls: "good" };
    if (skor >= 80) return { label: "Baik (B)", cls: "good" };
    if (skor >= 70) return { label: "Cukup (C)", cls: "gold" };
    return { label: "Perlu Bimbingan (D)", cls: "warn" };
  }

  function renderQuizPicker() {
    quizPicker.innerHTML = "";
    quizRunnerWrap.style.display = "none";
    quizPicker.style.display = "grid";
    EVALUASI.forEach((q) => {
      const materi = MATERI.find((m) => m.id === q.materiId);
      const result = progress.nilai[q.id];
      const card = document.createElement("div");
      card.className = "quiz-card";
      card.innerHTML = `
        <div class="bab">${materi ? materi.bab : ""}</div>
        <h3>${q.judul}</h3>
        <div class="info">${q.soal.length} soal pilihan ganda ${result ? "· Skor terakhir: <b>" + result.skor + "</b>" : currentStudent ? "· Belum dikerjakan" : "· Login untuk mengerjakan"}</div>
        <button class="${result ? "retake-btn" : "start-btn"}" data-id="${q.id}">${result ? "Kerjakan ulang" : "Mulai evaluasi"}</button>`;
      quizPicker.appendChild(card);
    });
    quizPicker.querySelectorAll("[data-id]").forEach((b) => {
      b.addEventListener("click", () => {
        if (!currentStudent) { openLogin(); return; }
        startQuiz(b.dataset.id);
      });
    });
  }

  function startQuiz(quizId) {
    const quiz = EVALUASI.find((q) => q.id === quizId);
    if (!quiz) return;
    quizPicker.style.display = "none";
    quizRunnerWrap.style.display = "block";
    let current = 0;
    const answers = new Array(quiz.soal.length).fill(null);

    function renderQuestion() {
      const s = quiz.soal[current];
      quizRunnerWrap.innerHTML = `
        <div class="quiz-runner">
          <div class="qprog">Soal ${current + 1} dari ${quiz.soal.length} · ${quiz.judul}</div>
          <div class="qprog-track"><div class="qprog-fill" style="width:${((current + 1) / quiz.soal.length) * 100}%"></div></div>
          <div class="q-text">${s.pertanyaan}</div>
          <div id="optWrap"></div>
          <div class="quiz-nav">
            <button class="nav-arrow ghost" id="prevBtn" ${current === 0 ? "disabled" : ""}>Sebelumnya</button>
            <button class="nav-arrow" id="nextBtn">${current === quiz.soal.length - 1 ? "Selesai" : "Berikutnya"}</button>
          </div>
        </div>`;
      const optWrap = quizRunnerWrap.querySelector("#optWrap");
      s.opsi.forEach((op, i) => {
        const elOpt = document.createElement("div");
        elOpt.className = "opt" + (answers[current] === i ? " selected" : "");
        elOpt.innerHTML = `<span class="letter">${String.fromCharCode(65 + i)}</span><span>${op}</span>`;
        elOpt.addEventListener("click", () => { answers[current] = i; renderQuestion(); });
        optWrap.appendChild(elOpt);
      });
      quizRunnerWrap.querySelector("#prevBtn").addEventListener("click", () => { if (current > 0) { current--; renderQuestion(); } });
      quizRunnerWrap.querySelector("#nextBtn").addEventListener("click", () => {
        if (current < quiz.soal.length - 1) { current++; renderQuestion(); } else { finishQuiz(); }
      });
    }

    async function finishQuiz() {
      let result;
      try {
        result = await api(`/api/evaluasi/${quiz.id}/submit`, {
          method: "POST",
          body: JSON.stringify({ studentId: currentStudent.id, answers }),
        });
      } catch (err) { alert(err.message); renderQuizPicker(); return; }

      progress.nilai[quiz.id] = { skor: result.skor, tanggal: new Date().toLocaleDateString("id-ID", { day: "numeric", month: "short", year: "numeric" }) };
      const pr = predikat(result.skor);
      const reviewHtml = result.review.map((r, i) => `
        <div class="review-item">
          <div class="qi">${i + 1}. ${r.pertanyaan}</div>
          <div class="ai ${r.benar ? "right" : "wrong"}">Jawabanmu: ${r.jawabanSiswa === null ? "(kosong)" : r.opsi[r.jawabanSiswa]} ${r.benar ? "— Benar" : "— Kurang tepat, jawaban benar: " + r.opsi[r.jawabanBenar]}</div>
        </div>`).join("");

      quizRunnerWrap.innerHTML = `
        <div class="quiz-runner">
          <div class="result-box">
            <div class="score-ring" style="--pct:${result.skor}"><div class="inner"><b>${result.skor}</b><span>dari 100</span></div></div>
            <div class="predikat">${pr.label}</div>
            <div class="desc">Kamu menjawab benar ${result.correct} dari ${result.total} soal pada ${quiz.judul}.</div>
            <button class="nav-arrow" id="backToList">Kembali ke daftar evaluasi</button>
          </div>
          <div class="review-list">${reviewHtml}</div>
        </div>`;
      quizRunnerWrap.querySelector("#backToList").addEventListener("click", () => renderQuizPicker());
    }

    renderQuestion();
  }

  // ---------- riwayat ----------
  async function renderRiwayat() {
    const el = document.getElementById("riwayatContent");
    if (!currentStudent) {
      el.innerHTML = `
        <div class="gate-box">
          <h3>Riwayat belum bisa ditampilkan</h3>
          <p>Login terlebih dahulu dengan memilih namamu dari daftar kelas, agar nilai, status materi, tugas, dan evaluasi kamu bisa ditampilkan di sini.</p>
          <button class="login-btn" id="gateLoginBtn" style="margin:0 auto;">Masuk sekarang</button>
        </div>`;
      document.getElementById("gateLoginBtn").addEventListener("click", openLogin);
      return;
    }

    // ambil data terbaru dari server (memastikan sinkron lintas perangkat)
    try {
      const data = await api("/api/riwayat/" + currentStudent.id);
      progress = data.progress;
    } catch (e) {}

    const materiDoneCount = MATERI.filter((m) => progress.materiDone[m.id]).length;
    const tugasDoneCount = TUGAS.filter((t) => progress.tugasDone[t.id]).length;
    const scores = EVALUASI.map((q) => progress.nilai[q.id]?.skor).filter((s) => s !== undefined);
    const rata = scores.length ? Math.round(scores.reduce((a, b) => a + b, 0) / scores.length) : null;

    el.innerHTML = `
      <div class="riwayat-head">
        <div class="av">${initials(currentStudent.nama)}</div>
        <div><h2>${currentStudent.nama}</h2><div class="k">Kelas ${currentStudent.kelas} · Riwayat Belajar PAI</div></div>
      </div>
      <div class="nilai-summary">
        <div class="stat-card"><div class="num">${rata === null ? "-" : rata}</div><div class="lbl">Rata-rata nilai evaluasi</div></div>
        <div class="stat-card"><div class="num">${materiDoneCount}/${MATERI.length}</div><div class="lbl">Bab dipelajari</div></div>
        <div class="stat-card"><div class="num">${tugasDoneCount}/${TUGAS.length}</div><div class="lbl">Tugas selesai</div></div>
      </div>
      <div class="subhead">Status Materi</div>
      <div class="status-list">${MATERI.map((m) => {
        const done = !!progress.materiDone[m.id];
        return `<div class="status-row"><span>${m.bab} — ${m.judul}</span><span class="pill ${done ? "good" : "warn"}">${done ? "Selesai dipelajari" : "Belum dipelajari"}</span></div>`;
      }).join("")}</div>
      <div class="subhead">Status Tugas</div>
      <div class="status-list">${TUGAS.map((t) => {
        const done = !!progress.tugasDone[t.id];
        return `<div class="status-row"><span>${t.judul}</span><span class="pill ${done ? "good" : "warn"}">${done ? "Selesai" : "Belum selesai"}</span></div>`;
      }).join("")}</div>
      <div class="subhead">Riwayat Evaluasi &amp; Nilai</div>
      <div class="chart-panel"><div id="riwayatChart"></div></div>
      <div class="overflow-x">
        <table class="nilai-table">
          <thead><tr><th>Bab</th><th>Evaluasi</th><th>Skor</th><th>Predikat</th><th>Tanggal</th></tr></thead>
          <tbody id="riwayatTbody"></tbody>
        </table>
      </div>`;

    const chartWrap = document.getElementById("riwayatChart");
    let rows = "";
    EVALUASI.forEach((q) => {
      const materi = MATERI.find((m) => m.id === q.materiId);
      const r = progress.nilai[q.id];
      const skor = r ? r.skor : 0;
      const bar = document.createElement("div");
      bar.className = "bar-row";
      bar.innerHTML = `<div class="lab">${materi.bab}</div><div class="bar-track"><div class="bar-fill" style="width:${skor}%"></div></div><div class="val">${r ? skor : "–"}</div>`;
      chartWrap.appendChild(bar);
      if (r) {
        const pr = predikat(r.skor);
        rows += `<tr><td>${materi.bab}</td><td>${q.judul}</td><td><b>${r.skor}</b></td><td><span class="pill ${pr.cls}">${pr.label}</span></td><td>${r.tanggal}</td></tr>`;
      }
    });
    document.getElementById("riwayatTbody").innerHTML = rows || `<tr><td colspan="5" class="empty-note">Belum ada evaluasi yang dikerjakan.</td></tr>`;
  }

  // ---------- info & beranda ----------
  function renderInfo() {
    document.getElementById("infoList").innerHTML = INFO.map((i) => `
      <div class="info-item">
        <div class="info-date"><div class="d">${i.tgl}</div><div class="m">${i.bln}</div></div>
        <div class="info-body"><h4>${i.judul}</h4><p>${i.isi}</p></div>
      </div>`).join("");
    document.getElementById("infoPreview").innerHTML = INFO.slice(0, 3).map((i) => `<div class="mini-row"><span>${i.judul}</span><span class="pill gold">${i.tgl} ${i.bln}</span></div>`).join("");
  }

  function renderBeranda() {
    document.getElementById("statMateriTotal").textContent = MATERI.length;
    document.getElementById("statTugasTotal").textContent = TUGAS.length;
    document.getElementById("statEvalTotal").textContent = EVALUASI.length;
    document.getElementById("statSiswa").textContent = ROSTER.length;
    document.getElementById("babPreview").innerHTML = MATERI.map((m) => `<div class="mini-row"><span>${m.bab} — ${m.judul}</span></div>`).join("");
    const teaser = document.getElementById("authTeaser");
    teaser.innerHTML = currentStudent
      ? `<p>Kamu login sebagai <b>${currentStudent.nama}</b> (Kelas ${currentStudent.kelas}). Lihat progres belajarmu di menu <b>Riwayat Saya</b>.</p>`
      : `<p>Kamu belum login. <b>Masuk</b> dengan memilih namamu agar nilai, tugas, dan status materimu tersimpan di server.</p>`;
  }

  function renderAll() {
    renderAuthArea();
    renderGreeting();
    renderMateri();
    renderTugas();
    renderQuizPicker();
    renderInfo();
    renderBeranda();
    if (document.getElementById("view-riwayat").classList.contains("active")) renderRiwayat();
  }

  // ---------- bootstrap ----------
  async function init() {
    try {
      [MATERI, TUGAS, EVALUASI, INFO, ROSTER] = await Promise.all([
        api("/api/materi"),
        api("/api/tugas"),
        api("/api/evaluasi"),
        api("/api/info"),
        api("/api/siswa"),
      ]);
    } catch (e) {
      document.querySelector("main").innerHTML = `<div class="gate-box"><h3>Tidak dapat terhubung ke server</h3><p>${e.message}. Pastikan backend (server.js) sedang berjalan.</p></div>`;
      return;
    }
    await restoreSession();
    renderAll();
  }

  init();
})();
