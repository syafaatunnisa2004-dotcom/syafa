// server.js
// Backend Portal Akademik PAI Kelas VIII.
// Menjalankan: npm install lalu npm start (lihat README.md).

const express = require("express");
const multer = require("multer");
const XLSX = require("xlsx");
const cors = require("cors");
const path = require("path");

const store = require("./lib/store");

const app = express();
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 5 * 1024 * 1024 }, // maks 5MB
});

store.ensureDataFiles();

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

// ================= SISWA & LOGIN =================

// Daftar siswa (dipakai untuk mengisi jendela login di frontend)
app.get("/api/siswa", (req, res) => {
  const roster = store.getSiswa().map((s) => ({ id: s.id, nama: s.nama, kelas: s.kelas }));
  res.json(roster);
});

// "Login" = memilih nama dari daftar, tanpa kata sandi
app.post("/api/login", (req, res) => {
  const { studentId } = req.body || {};
  const siswa = store.getSiswa().find((s) => s.id === studentId);
  if (!siswa) return res.status(404).json({ error: "Siswa tidak ditemukan. Hubungi guru jika namamu belum terdaftar." });
  res.json(siswa);
});

// Impor / ganti daftar siswa dari file Excel (.xlsx) atau CSV
// Kolom yang dibaca: Nama, Kelas, NIS (opsional). Nama header tidak case-sensitive.
app.post("/api/admin/import-siswa", upload.single("file"), (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: "File tidak ditemukan. Kirim field 'file' berisi .xlsx atau .csv." });

    const workbook = XLSX.read(req.file.buffer, { type: "buffer" });
    const sheet = workbook.Sheets[workbook.SheetNames[0]];
    const rows = XLSX.utils.sheet_to_json(sheet, { defval: "" });

    const roster = rows
      .map((row, idx) => {
        const get = (keys) => {
          for (const k of Object.keys(row)) {
            if (keys.includes(k.trim().toLowerCase())) return String(row[k]).trim();
          }
          return "";
        };
        const nama = get(["nama", "name"]);
        const kelas = get(["kelas", "class"]);
        const nis = get(["nis", "no induk", "nomor induk"]);
        if (!nama) return null;
        const slug = nama.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
        return { id: nis ? "nis-" + nis : `${slug}-${idx}`, nama, kelas: kelas || "-", nis: nis || null };
      })
      .filter(Boolean);

    if (roster.length === 0) {
      return res.status(400).json({ error: "Tidak ada baris valid. Pastikan ada kolom 'Nama' yang terisi." });
    }

    store.setSiswa(roster);
    res.json({ imported: roster.length, roster });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Gagal membaca file. Pastikan formatnya .xlsx atau .csv yang valid." });
  }
});

// ================= KONTEN PEMBELAJARAN =================

app.get("/api/materi", (req, res) => res.json(store.getMateri()));
app.get("/api/tugas", (req, res) => res.json(store.getTugas()));
app.get("/api/info", (req, res) => res.json(store.getInfo()));

// Daftar evaluasi TANPA kunci jawaban (supaya tidak bisa dibaca dari sisi klien)
app.get("/api/evaluasi", (req, res) => {
  const evaluasi = store.getEvaluasi().map((q) => ({
    id: q.id,
    materiId: q.materiId,
    judul: q.judul,
    soal: q.soal.map((s) => ({ pertanyaan: s.pertanyaan, opsi: s.opsi })),
  }));
  res.json(evaluasi);
});

// Submit jawaban evaluasi -> skor dihitung di server, tersimpan sebagai nilai siswa
app.post("/api/evaluasi/:id/submit", (req, res) => {
  const { studentId, answers } = req.body || {};
  if (!studentId || !store.getSiswa().find((s) => s.id === studentId)) {
    return res.status(401).json({ error: "Siswa belum login." });
  }
  const quiz = store.getEvaluasi().find((q) => q.id === req.params.id);
  if (!quiz) return res.status(404).json({ error: "Evaluasi tidak ditemukan." });
  if (!Array.isArray(answers)) return res.status(400).json({ error: "Jawaban tidak valid." });

  let correct = 0;
  const review = quiz.soal.map((s, i) => {
    const jawabanSiswa = answers[i] ?? null;
    const benar = jawabanSiswa === s.jawaban;
    if (benar) correct++;
    return { pertanyaan: s.pertanyaan, opsi: s.opsi, jawabanBenar: s.jawaban, jawabanSiswa, benar };
  });

  const skor = Math.round((correct / quiz.soal.length) * 100);
  const tanggal = new Date().toLocaleDateString("id-ID", { day: "numeric", month: "short", year: "numeric" });

  store.saveNilai(studentId, quiz.id, { skor, tanggal });
  res.json({ skor, correct, total: quiz.soal.length, review });
});

// ================= PROGRESS (materi & tugas) =================

app.post("/api/progress/materi", (req, res) => {
  const { studentId, materiId, done } = req.body || {};
  if (!studentId || !store.getSiswa().find((s) => s.id === studentId)) {
    return res.status(401).json({ error: "Siswa belum login." });
  }
  const progress = store.setMateriDone(studentId, materiId, !!done);
  res.json(progress);
});

app.post("/api/progress/tugas", (req, res) => {
  const { studentId, tugasId, done } = req.body || {};
  if (!studentId || !store.getSiswa().find((s) => s.id === studentId)) {
    return res.status(401).json({ error: "Siswa belum login." });
  }
  const progress = store.setTugasDone(studentId, tugasId, !!done);
  res.json(progress);
});

// ================= RIWAYAT (nilai + status materi/tugas per siswa) =================

app.get("/api/riwayat/:studentId", (req, res) => {
  const siswa = store.getSiswa().find((s) => s.id === req.params.studentId);
  if (!siswa) return res.status(404).json({ error: "Siswa tidak ditemukan." });
  const progress = store.getProgress(req.params.studentId);
  res.json({ siswa, progress });
});

// ================= START =================

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Portal PAI backend berjalan di http://localhost:${PORT}`);
});
